#include "plugin.h"

void initialize() {
    mfp_register("Hello World!");
}
